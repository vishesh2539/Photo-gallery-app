import React from 'react';

const Navbar = ({ toggleDarkMode, darkMode }) => {
  return (
    <div className="navbar">
      <h1>Photo Gallery</h1>
      <button onClick={toggleDarkMode} className="toggle-dark-mode">
        {darkMode ? 'Light Mode' : 'Dark Mode'}
      </button>
      <hr></hr>
    </div>
  );
};

export default Navbar;
