// src/components/Album.js
import React from 'react';

const Album = ({ album, onClick, isSelected, onSelect, deleteMode }) => {
  return (
    <div className="album" onClick={() => onClick(album)}>
      {deleteMode && (
        <input
          type="checkbox"
          checked={isSelected}
          onChange={() => onSelect(album)}
          onClick={(e) => e.stopPropagation()}
        />
      )}
      <h2>{album.name}</h2>
    </div>
  );
};

export default Album;
