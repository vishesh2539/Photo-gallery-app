import React from 'react';

const Photo = ({ photo, isSelected, onSelect, deleteMode, onDoubleClick }) => {
  return (
    <div className="photo-wrapper">
      {deleteMode && (
        <input
          type="checkbox"
          checked={isSelected}
          onChange={() => onSelect(photo)}
        />
      )}
      <img
        src={photo.src}
        alt={photo.alt}
        onDoubleClick={onDoubleClick}
      />
    </div>
  );
};

export default Photo;
