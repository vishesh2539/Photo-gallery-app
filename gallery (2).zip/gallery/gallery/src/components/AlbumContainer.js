import React, { useState } from 'react';

const AlbumContainer = ({ albums, onAlbumSelect, setAlbums }) => {
  const [deleteMode, setDeleteMode] = useState(false);
  const [selectedAlbums, setSelectedAlbums] = useState([]);
  const [renameMode, setRenameMode] = useState(false);

  const toggleAlbumSelection = (album) => {
    if (selectedAlbums.includes(album)) {
      setSelectedAlbums(selectedAlbums.filter(a => a !== album));
    } else {
      setSelectedAlbums([...selectedAlbums, album]);
    }
  };

  const handleAddAlbum = () => {
    const albumName = prompt('Enter new album name:');
    if (albumName) {
      setAlbums([...albums, { name: albumName, photos: [] }]);
    }
  };

  const handleDeleteAlbums = () => {
    setDeleteMode(true);
  };

  const confirmDeleteAlbums = () => {
    if (window.confirm('Are you sure you want to delete the selected albums?')) {
      setAlbums(albums.filter(album => !selectedAlbums.includes(album)));
      setSelectedAlbums([]);
      setDeleteMode(false);
    }
  };

  const cancelDeleteMode = () => {
    setDeleteMode(false);
    setSelectedAlbums([]);
  };

  const handleRenameAlbums = () => {
    setRenameMode(true);
  };

  const confirmRenameAlbum = () => {
    if (selectedAlbums.length === 1) {
      const newName = prompt('Enter new album name:');
      if (newName) {
        setAlbums(albums.map(album =>
          album.name === selectedAlbums[0].name ? { ...album, name: newName } : album
        ));
        setSelectedAlbums([]);
        setRenameMode(false);
      }
    } else {
      alert('Please select exactly one album to rename.');
    }
  };

  const cancelRenameMode = () => {
    setRenameMode(false);
    setSelectedAlbums([]);
  };

  return (
    <div className="album-container">
      <div className="albums">
        {albums.map((album, index) => (
          <div
            key={index}
            className="album"
            onClick={() => onAlbumSelect(album)}
          >
            {(deleteMode || renameMode) && (
              <input
                type="checkbox"
                checked={selectedAlbums.includes(album)}
                onChange={() => toggleAlbumSelection(album)}
              />
            )}
            <div>{album.name}</div>
          </div>
        ))}
      </div>
      <div className="album-buttons">
        <button onClick={handleAddAlbum}>Add Album</button>
        <button onClick={handleDeleteAlbums}>Delete Album</button>
        {deleteMode && (
          <div>
            <button onClick={confirmDeleteAlbums}>Confirm</button>
            <button onClick={cancelDeleteMode}>Cancel</button>
          </div>
        )}
        <button onClick={handleRenameAlbums}>Rename Album</button>
        {renameMode && (
          <div>
            <button onClick={confirmRenameAlbum}>Confirm</button>
            <button onClick={cancelRenameMode}>Cancel</button>
          </div>
        )}
      </div>
    </div>
  );
};

export default AlbumContainer;
