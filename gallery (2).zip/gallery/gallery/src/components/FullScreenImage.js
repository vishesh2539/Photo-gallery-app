// src/components/FullScreenImage.js
import React, { useState } from 'react';

const FullScreenImage = ({ photo, photos, closeFullScreen }) => {
  const [currentIndex, setCurrentIndex] = useState(photos.indexOf(photo));

  const prevImage = () => {
    setCurrentIndex((currentIndex - 1 + photos.length) % photos.length);
  };

  const nextImage = () => {
    setCurrentIndex((currentIndex + 1) % photos.length);
  };

  const closeFullScreenView = () => {
    closeFullScreen();
  };

  return (
    <div className="fullscreen-overlay">
      <button className="close-button" onClick={closeFullScreenView}>X</button>
      <button className="prev-button" onClick={prevImage}>&lt;</button>
      <img src={photos[currentIndex].src} alt={photos[currentIndex].alt} className="fullscreen-image" />
      <button className="next-button" onClick={nextImage}>&gt;</button>
    </div>
  );
};

export default FullScreenImage;
