import React, { useState, useEffect } from 'react';
import Photo from './Photo';
import FullScreenImage from './FullScreenImage';

const PhotoContainer = ({ album, albums, updateAlbumPhotos, setAlbums }) => {
  const [photos, setPhotos] = useState(album.photos);
  const [deleteMode, setDeleteMode] = useState(false);
  const [selectedPhotos, setSelectedPhotos] = useState([]);
  const [showFullScreen, setShowFullScreen] = useState(false);
  const [fullScreenPhoto, setFullScreenPhoto] = useState(null);

  useEffect(() => {
    setPhotos(album.photos);
  }, [album]);

  const handleAddPhoto = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const newPhoto = { src: reader.result, alt: file.name };
        const updatedPhotos = [...photos, newPhoto];
        setPhotos(updatedPhotos);
        updateAlbumPhotos(album.name, updatedPhotos);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDeletePhotos = () => {
    setDeleteMode(true);
  };

  const confirmDeletePhotos = () => {
    if (window.confirm('Are you sure you want to delete the selected photos?')) {
      const recycleBin = albums.find(a => a.name === 'Recycle Bin');
      const photosToMove = selectedPhotos;
      const remainingPhotos = photos.filter(photo => !selectedPhotos.includes(photo));

      // Move selected photos to Recycle Bin
      const updatedRecycleBinPhotos = [...recycleBin.photos, ...photosToMove];
      const updatedAlbums = albums.map(album => 
        album.name === 'Recycle Bin' ? { ...album, photos: updatedRecycleBinPhotos } : album
      );

      // Update current album photos
      updateAlbumPhotos(album.name, remainingPhotos);

      // Ensure the Recycle Bin album is updated in the global albums state
      setAlbums(updatedAlbums.map(a => 
        a.name === album.name ? { ...a, photos: remainingPhotos } : a
      ));

      setSelectedPhotos([]);
      setDeleteMode(false);
    }
  };

  const cancelDeleteMode = () => {
    setDeleteMode(false);
    setSelectedPhotos([]);
  };

  const handlePhotoSelect = (photo) => {
    if (selectedPhotos.includes(photo)) {
      setSelectedPhotos(selectedPhotos.filter(p => p !== photo));
    } else {
      setSelectedPhotos([...selectedPhotos, photo]);
    }
  };

  const handleDoubleClick = (photo) => {
    setFullScreenPhoto(photo);
    setShowFullScreen(true);
  };

  const closeFullScreen = () => {
    setShowFullScreen(false);
    setFullScreenPhoto(null);
  };

  return (
    <div className="photo-container">
      <h2>{album.name}</h2>
      <div className="photo-buttons">
        <label htmlFor="file-input" className="label-button">Add Photo</label>
        <input id="file-input" type="file" onChange={handleAddPhoto} />
        <button onClick={handleDeletePhotos}>Delete Photo</button>
        {deleteMode && (
          <div>
            <button onClick={confirmDeletePhotos}>Confirm</button>
            <button onClick={cancelDeleteMode}>Cancel</button>
          </div>
        )}
      </div>
      <div className="photos-grid">
        {photos.map((photo, index) => (
          <Photo
            key={index}
            photo={photo}
            isSelected={selectedPhotos.includes(photo)}
            onSelect={handlePhotoSelect}
            deleteMode={deleteMode}
            onDoubleClick={() => handleDoubleClick(photo)}
          />
        ))}
      </div>
      {showFullScreen && fullScreenPhoto && (
        <FullScreenImage
          photo={fullScreenPhoto}
          photos={photos}
          closeFullScreen={closeFullScreen}
        />
      )}
    </div>
  );
};

export default PhotoContainer;
