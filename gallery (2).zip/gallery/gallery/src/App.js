import React, { useState } from 'react';
import Navbar from './components/Navbar';
import AlbumContainer from './components/AlbumContainer';
import PhotoContainer from './components/PhotoContainer';
import './App.css';

const App = () => {
  const [albums, setAlbums] = useState([
    { name: 'Album 1', photos: [] },
    { name: 'Album 2', photos: [] },
    { name: 'Recycle Bin', photos: [] },
  ]);
  const [selectedAlbum, setSelectedAlbum] = useState(albums[0]);
  const [darkMode, setDarkMode] = useState(false);

  const handleAlbumSelect = (album) => {
    setSelectedAlbum(album);
  };

  const updateAlbumPhotos = (albumName, photos) => {
    setAlbums(albums.map(album => 
      album.name === albumName ? { ...album, photos } : album
    ));
  };

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  return (
    <div className={`app ${darkMode ? 'dark-mode' : ''}`}>
      <Navbar toggleDarkMode={toggleDarkMode} darkMode={darkMode} />
      <AlbumContainer 
        albums={albums} 
        onAlbumSelect={handleAlbumSelect} 
        setAlbums={setAlbums} 
      />
      {selectedAlbum && (
        <PhotoContainer
          album={selectedAlbum}
          albums={albums}
          updateAlbumPhotos={updateAlbumPhotos}
          setAlbums={setAlbums}
        />
      )}
    </div>
  );
};

export default App;
